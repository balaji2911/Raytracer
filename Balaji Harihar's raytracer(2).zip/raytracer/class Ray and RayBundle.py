# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 14:45:36 2019

@author: bh1118
"""
import numpy
import matplotlib.pyplot as plt
class Ray():
    def __init__(self, p=[0.0,0.0,0.0], k=[0.0,0.0,1.0]):
       
        self.position = numpy.array(p)
        self.direction = numpy.array(k)
        self._plist = [self.position]
        self._klist = [self.direction]
        
    def p(self):
        return self.position
    def k(self):
       return self.direction
    def append(self,p,k):
        self._plist.append(p)
        self._klist.append(k)
    def vertices(self):
        return self._plist, self._klist
    def rayplot(self,ray):
       
        T = numpy.array(self._plist)
        x = (T[0][2],T[1][2],T[2][2])
        y = (T[0][1],T[1][1],T[2][1])
        plt.xlabel('z/mm')
        plt.ylabel('y/mm')
        plt.title('Ray Path')
        plt.plot(x,y)
        plt.show()
        plt.grid()

   
    __doc__ = """
    This class comprises of all necessary codes for the ray
"""


class RayBundle:
    def __init__(self, R = [0.5,1,1.5,2,2.5], N = [5,10,15,20,25], p = [0,0,0], k = [0,0,1]):
        self.centre=numpy.array(p)
        self.direction=numpy.array(k)
        self.bundlelist=[Ray(p,k)]
        for i,alpha in enumerate(R):#this line and the one below helps form a connection between R and N 
            conn = N[i] #and their indices, so associates R[0] with N[0] and so on 
            for j in range(0,conn):
                height = (2*numpy.pi/conn)*j
                beam_p=self.centre+[numpy.cos(height)*alpha,numpy.sin(height)*alpha,0]
                u=Ray([beam_p[0],beam_p[1],beam_p[2]],[0,0,1])
                self.bundlelist.append(u)
                
    def beamplot(self,ray):
        for alpha in self.bundlelist:
            X = numpy.array(alpha._plist)
            y=X[:,2]
            z=X[:,1]
            plt.plot(y,z)
            plt.xlabel('z/mm')
        plt.ylabel('y/mm')
        plt.title('Ray Path for Collimated Beam')
        plt.show()
        plt.grid()
        
    def spotdiagram(self,ray):
        for alpha in self.bundlelist:
            Y = numpy.array(alpha._plist)
            x=Y[:,1]
            y=Y[:,0]
            plt.plot(x,y,'ro')
            plt.xlabel('x/mm')
        plt.ylabel('y/mm')
        plt.title('Spot Diagram for Collimated Beam')
        plt.show()
        plt.grid()          
           
        
    __doc__ = "This class defines the bundle of rays/uniform collimated beam"
   

   



            

    
            