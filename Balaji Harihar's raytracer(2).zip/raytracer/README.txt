This is the ReadMe file for the RayTracer

The principle operation of the code is such that the various points and intersections are appended and stored in a list, and then these points are plotted to trace the path of the ray.

Ray class:

__init__ : starting position 'p' : [0,0,0] and this can be adjusted as per the user's discretion
	   starting direction 'k' : [0,0,1] and this can be adjusted as per the user's discretion
	   both the 'p' and 'k' arrays are added to the lists self._plist and self._klist respectively

A ray can be defined as follows in the iPython console : r = Ray(p = [a,b,c], k = [x,y,z])

append : this function appends the entered value for 'p' and 'k' into self._plist and self._klist respectively

rayplot : this function traces out the path of the ray by plotting values of all the points 'p' in self._plist 

SphericalRefraction class:

__init__ : 'z0' : the intercept of the spherical surface with the optical axis
           'n1' : refractive index to the left of the point of intersection
           'n2' : refractive index to the right of the point of intersection
           'aper' : radius of aperture of the spherical surface
           '1/R' : radius of curvature of the spherical surface
           'self.centre' : the centre of the spherical surface 

intercept :  if curvature is not zero, it returns the point of intersection between the ray and the surface. 
             if spherical lens is 0, the spherical surface becomes a plane with normal [0,0,1]

propagate_ray: adds both the intercept return to the list of positions in the ray class and refractedray return to list of directions

propagate_raybundle: implements propagate_ray function for every element in raybundle list

in order to propagate a ray through this class:
ray=Ray([0,0,0],[0,0,1])
surface=SphericalRefraction()
surface.propagate_ray(ray)

OutputPlane class:

__init__ : 'planecoord' : the intercept of the plane with the optical axis


intercept : finds the intercept of the refracted ray from the spherical surface with this plane

propagate_ray: adds the intercept function to the list of positions in the Ray class

this class can be used the same way as the SphericalRefraction class

RayBundle class :

__init__ 'R' : this inputs the list of different radii as an array
         'N' : inputs number of rays corresponding to the respective radius in 'R'
         'p' : inputs the centre point of the bundle
         'k' : inputs the direction of each ray in the bundle
         for loop generates parallel rays using Ray class parameters and creates a bundle with set radii R
beamplot : plots the path of the uniform collimated beam

spotdiagram : plots the beam in the xy plane

to use this class : r = RayBundle()
surface = SphericalRefraction()
plane = OutputPlane()
surface.propagate_raybundle(r)
plane.propagate_raybundle(r)
r.beamplot(r)
r.spotdiagram(r)
