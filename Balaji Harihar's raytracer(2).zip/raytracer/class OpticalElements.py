import numpy


class OpticalElement:
  def propagate_ray(self, ray):
    "propagate a ray through the optical element"
   
    raise NotImplementedError()
   
   
class SphericalRefraction(OpticalElement):
    l1 = 0
    l2 = 0
 
    def __init__(self,z0=[0.0,0.0,100.0],R=0.03,n1=1,n2=1.5, aper = 100):
       self.zintercept= numpy.array(z0)
       self.radcurv=1/R
       self.refind1=n1
       self.refind2=n2
       self.aperture=aper
       self.centre = numpy.array(z0) + numpy.array([0,0,1/R])
   
    def intercept(self,ray):
        k = ray.k()
        p = ray.p()

       
        a = numpy.dot(p-self.centre, k/numpy.linalg.norm(k) )**2
       
        b = (numpy.dot(p-self.centre,p-self.centre)) - (self.radcurv)**2
        c = numpy.sqrt(a-b)
        if c < 0:
            return "Invalid Value Encountered In Square Root"
        else:
            if self.radcurv == 0:
                k = [0,0,1]
            else:
                l1= -(numpy.dot(p-self.centre, k/numpy.linalg.norm(k))) + c
                l2= -(numpy.dot(p-self.centre, k/numpy.linalg.norm(k))) - c
        #l1 = -(numpy.dot(r, k/numpy.linalg.norm(k)) + numpy.sqrt( (numpy.dot(r, k/numpy.linalg.norm(k)))**2 - (numpy.dot(r,r))**2 - (1/R)**2) )
        #l2 = -(numpy.dot(r, k/numpy.linalg.norm(k)) - numpy.sqrt((numpy.dot(r, k/numpy.linalg.norm(k)))**2 - (numpy.dot(r,r))**2 - (1/R)**2))
       
     
        if l1 > l2 and numpy.linalg.norm((p+(l2*k))-self.zintercept) < self.aperture:
            return (p + k/numpy.linalg.norm(k)*l2)
             
            print(p + k/numpy.linalg.norm(k)*l2)
        elif l2 > l1 and numpy.linalg.norm((p+(l1*k))-self.zintercept) < self.aperture:
            return (p + k/numpy.linalg.norm(k)*l1)
           
            print(p + k/numpy.linalg.norm(k)*l1)
        else:
            return None
           
    def refract(self,ray):
        unitnormalvector = (self.intercept(ray) - self.centre)/numpy.linalg.norm(self.intercept(ray) - self.centre)
        khat = ray.k()
        ratio = self.refind1/self.refind2
        ncrosskhat = numpy.cross(unitnormalvector, khat)
        ndotkhat = numpy.dot(unitnormalvector,khat)
        if numpy.sin(numpy.arccos(ndotkhat)) > (1/ratio):
            return None
        else:  
            return ratio*numpy.cross(unitnormalvector,-ncrosskhat) -(numpy.sqrt(1-ratio**2*numpy.dot(ncrosskhat,ncrosskhat)))*unitnormalvector
     
       
    def propagate_ray(self,ray):
        a = self.intercept(ray)
        b = self.refract(ray)
       
       
       
        if self.intercept(ray) is None:
            print ("Invalid Point")
        elif self.refract(ray) is None:
            print( "Invalid Direction")
        else:
            ray._plist.append([a[0],a[1],a[2]])
            ray._klist.append([b[0],b[1],b[2]])
            return a,b
       
    def propagate_raybundle(self,raybundle):
        for i in raybundle.bundlelist:
            self.propagate_ray(i)
            
class OutputPlane(OpticalElement):
    a = SphericalRefraction()
    def __init__(self, planecoord = [0,0,200]):
        self.coordinates = numpy.array(planecoord)
        
       
      
    def intercept(self,ray):
        a = SphericalRefraction()
        p1 = a.intercept(ray)
        k1 = a.refract(ray)
        pc = self.coordinates
        l = (pc[2]-p1[2])/k1[2]
        if k1[2] == 0:
            return "No Intercept With The Plane"
        else:
            return p1 + l*k1
           
       
       
    def propagate_ray(self,ray):
        a1 = self.intercept(ray)
        ray._plist.append([a1[0],a1[1],a1[2]])
        return a1
        
    def propagate_raybundle(self,raybundle):
        for i in raybundle.bundlelist:
            self.propagate_ray(i)
       
    __doc__ =    """This module contains the base class OpticalElement and all methods to refract are described here"""